# Confidant

A single-file web app that chats with you like a real friend and uses what it learns to generate personalized jokes and advice — powered by the Anthropic Claude API.

---

## What it does

Confidant has three modes:

- **Chat** — A natural conversation. It opens with a different question every day and talks like a person, not a chatbot. Behind the scenes it quietly builds a picture of who you are.
- **Joke** — Generates a joke tailored to your life. The more you've chatted, the more personal it gets.
- **Advice** — Gives one honest, specific piece of advice based on what it knows about you. No generic platitudes.

---

## Project structure

```
confidant/
├── index.html   # The entire app — UI, styles, and all three agents
├── AGENTS.md    # Agent definitions, system prompts, and data contracts
└── README.md    # This file
```

Everything lives in `index.html`. There is no build step, no framework, no dependencies to install.

---

## Setup

### 1. Get an API key

Sign up at [console.anthropic.com](https://console.anthropic.com) and create an API key under **Settings → API Keys**.

### 2. Add your key to the app

Open `index.html` in any text editor. Near the bottom, find:

```js
var API_KEY = 'YOUR_API_KEY_HERE';
```

Replace `YOUR_API_KEY_HERE` with your actual key.

### 3. Open in a browser

Just double-click `index.html` or drag it into a browser tab. No server needed.

---

## How the agents work

See [`AGENTS.md`](./AGENTS.md) for full details. In short:

| Agent | Triggered by | Reads | Writes |
|---|---|---|---|
| Conversation Agent | Every chat message | `history[]` | `history[]`, `traits[]` |
| Joke Agent | "New joke" / "Wild card" | `traits[]` | — |
| Advice Agent | "New advice" / "Surprise me" | `traits[]` | — |

The `traits[]` array is the connective tissue — the Conversation Agent fills it silently, and the Joke and Advice agents use it to make their output feel personal.

---

## Running in production

Calling the Anthropic API directly from a browser exposes your API key in client-side code. This is fine for local/personal use, but for a public deployment you should:

1. Create a small backend (Node, Python, etc.) that holds the API key server-side
2. Have the frontend POST to your backend, which proxies the request to Anthropic
3. Add rate limiting and auth as needed

---

## Customization

**Change the opening questions** — Edit the `OPENERS` array in `index.html`. One is picked at random on each "Start over".

**Change the model** — Edit `var MODEL = 'claude-sonnet-4-20250514'`. Any Anthropic model string works.

**Tune the agents** — Edit the system prompts inside the `CHAT_SYSTEM` variable and the `systems` object in the `gen()` function. See `AGENTS.md` for the full prompt text.

**Persist traits across sessions** — The current implementation stores everything in memory (resets on page reload). To persist, save `traits` and `history` to `localStorage` and reload them on init.

---

## License

MIT — do whatever you want with it.
